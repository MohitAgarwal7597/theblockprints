'use client'

const VideoCards = () => {
  const videos = [
    {
      id: 1,
      src: '/videos/product-1.mp4',
      title: 'Handblock Printing Process',
      poster: '/images/video-posters/video-1.jpg',
    },
    {
      id: 2,
      src: '/videos/product-2.mp4',
      title: 'Silk Saree Collection',
      poster: '/images/video-posters/video-2.jpg',
    },
    {
      id: 3,
      src: '/videos/product-3.mp4',
      title: 'Custom Printing Demo',
      poster: '/images/video-posters/video-3.jpg',
    },
    {
      id: 4,
      src: '/videos/product-4.mp4',
      title: 'Fabric Quality Showcase',
      poster: '/images/video-posters/video-4.jpg',
    },
    {
      id: 5,
      src: '/videos/product-5.mp4',
      title: 'Behind the Scenes',
      poster: '/images/video-posters/video-5.jpg',
    },
  ]

  return (
    <section className="section-padding bg-light">
      <div className="container-custom">
        <div className="text-center mb-12 animate-on-scroll">
          <h2 className="text-4xl md:text-5xl font-philosopher mb-4">
            See Our Craft in Motion
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Watch how we create beautiful textiles with traditional techniques and modern designs
          </p>
        </div>

        <div className="video-cards-container">
          {videos.map((video, index) => (
            <div
              key={video.id}
              className={`video-card animate-on-scroll stagger-${(index % 5) + 1}`}
            >
              <video
                src={video.src}
                poster={video.poster}
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover"
              >
                Your browser does not support the video tag.
              </video>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <h3 className="text-white font-philosopher text-xl">
                  {video.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default VideoCards
